"""
Haber Nexus - Haber Uygulaması
Geliştirilmiş İçerik Üretim Sistemi ile birlikte
"""

default_app_config = 'news.apps.NewsConfig'
